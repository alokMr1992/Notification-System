package com.wing.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseUtil {

	private static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
	private static final String USERNAME = "prc";
	private static final String PASSWORD = "prc";

	public static Connection getConnection() {
		Connection con = null;

		try {
			Class.forName(DRIVER);
			con = DriverManager.getConnection(URL, USERNAME, PASSWORD);

		} catch (ClassNotFoundException e) {

			System.out.println(e.getMessage());
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		}
		return con;

	}

	public static void closeStatement(PreparedStatement pst) {

		if (pst != null) {

			try {
				pst.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}

	public static void closeConnection(Connection con) {

		if (con != null) {

			try {
				con.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}

	public static void closeResultset(ResultSet rs) {

		if (rs != null) {

			try {
				rs.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
	}
}