package com.wing.bean;

public class Notification {
	
	private String id;
	private String notification;
	
	public Notification() {
		// TODO Auto-generated constructor stub
	}
	
	public Notification(String id, String notification) {
		super();
		this.id = id;
		this.notification = notification;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNotification() {
		return notification;
	}

	public void setNotification(String notification) {
		this.notification = notification;
	}
	
	

}
