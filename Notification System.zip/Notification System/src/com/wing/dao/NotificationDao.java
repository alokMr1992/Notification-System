package com.wing.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.wing.bean.Notification;
import com.wing.util.DatabaseUtil;

public class NotificationDao {

	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	public int setNotification(String notification) {
		int res = 0;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			try {
				String sql = "insert into Notification(id,notification) values('NO_'||n_seq.nextval,?)";
				pst = con.prepareStatement(sql);
				pst.setString(1, notification);
				res = pst.executeUpdate();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				DatabaseUtil.closeStatement(pst);
				DatabaseUtil.closeConnection(con);
			}
		}
		return res;
	}

	public int getUnreadNotificationCount(int unread) {
		int count = 0;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			try {
				String sql = "Select count(id) from Notification where status=?";
				pst = con.prepareStatement(sql);
				pst.setInt(1, unread);
				rs = pst.executeQuery();
				while (rs.next()) {
					count = rs.getInt(1);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				DatabaseUtil.closeResultset(rs);
				DatabaseUtil.closeStatement(pst);
				DatabaseUtil.closeConnection(con);
			}
		}
		return count;
	}

	public ArrayList<Notification> getNotification() {
		ArrayList<Notification> newNotification = new ArrayList<Notification>();
		Notification notify = null;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			try {
				String sql = "Select notification from Notification Order By id Desc";
				pst = con.prepareStatement(sql);
				rs = pst.executeQuery();
				while (rs.next()) {
					notify = new Notification();
					notify.setNotification(rs.getString(1));
					newNotification.add(notify);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				DatabaseUtil.closeResultset(rs);
				DatabaseUtil.closeStatement(pst);
				DatabaseUtil.closeConnection(con);
			}
		}
		return newNotification;
	}

	public int changeNotificationStatus(int read, int unread) {
		int update = 0;
		con = DatabaseUtil.getConnection();
		if (con != null) {
			try {
				String sql = "Update Notification set status=? where status=?";
				pst = con.prepareStatement(sql);
				pst.setInt(1, read);
				pst.setInt(2, unread);
				update = pst.executeUpdate();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			} finally {
				DatabaseUtil.closeStatement(pst);
				DatabaseUtil.closeConnection(con);
			}
		}
		return update;
	}
}