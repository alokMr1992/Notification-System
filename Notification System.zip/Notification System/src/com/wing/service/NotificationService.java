package com.wing.service;

import java.util.ArrayList;

import com.wing.bean.Notification;
import com.wing.dao.NotificationDao;

public class NotificationService {

	NotificationDao dao = new NotificationDao();
	
	public int setNotification(String notification) {
		int res = dao.setNotification(notification);
		return res;
	}

	public int getUnreadNotificationCount(int unread) {
		int count = dao.getUnreadNotificationCount(unread);
		return count;
	}

	public ArrayList<Notification> getNotification() {
		ArrayList<Notification> newNotification = dao.getNotification();
		return newNotification;
	}

	public int changeNotificationStatus(int read, int unread) {
		int update = dao.changeNotificationStatus(read,unread);
		return update;
	}

}
