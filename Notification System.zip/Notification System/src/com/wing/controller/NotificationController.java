package com.wing.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wing.bean.Notification;
import com.wing.service.NotificationService;

/**
 * Servlet implementation class NotificationController
 */
public class NotificationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private NotificationService service = new NotificationService();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NotificationController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/event-stream");
		response.setCharacterEncoding("UTF-8");
        response.setHeader("Cache-Control","no-cache");
       	PrintWriter out = response.getWriter();
        int unread = 1;
        int read = 0;
        String action = request.getParameter("action");
        Date date = new Date();
        String currentDate = date.toString();
        String notification = "The server time is " + currentDate;
        int res = service.setNotification(notification);
        if(res > 0){
        	System.out.println("Insertion Success");
        }
        int unreadCount = service.getUnreadNotificationCount(unread);
        out.write("event:count\n");
        out.write("data: " + unreadCount + "\n\n");

        ArrayList<Notification> newNotification = service.getNotification();
        if("getNotification".equalsIgnoreCase(action)){     	
        	if(newNotification!= null){
        		for(Notification n : newNotification){
        			out.write("event:notification\n");
        			out.write("data: " + n.getNotification() + "\n\n");
                }
        		if(unreadCount > 0){
        			int update = service.changeNotificationStatus(read,unread);
        			if(update > 0){
        				System.out.println("Update Successful");
        			}
        		}
        	}
        }
        out.flush();
        out.close();
	}
}