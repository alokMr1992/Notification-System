create table Notification
(
	id varchar2(10) primary key,
	notification varchar2(100) not null,
	status number default 1 not null,
	TIMESTAMP TIMESTAMP(0) default CURRENT_TIMESTAMP
);

select * from NOTIFICATION;

create sequence n_seq start with 1 increment by 1 nocache nocycle;

insert into NOTIFICATION(id,notification) values('NO_'||n_seq.nextval,'This is server generated notification');