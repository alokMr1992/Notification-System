Steps to setup Front End:-

1. Install any text editor like notepad. (Any IDE like eclipse would be handy)
2. Install any web browser like chrome to run the .html or .jsp file.

NOTE: This application will not run on the Internate Explorer.

Steps to setup Back End:-

1. Install Oracle XE version 10 for database.
2. Install jdk(7 or above) to run the application and have it in your PATH or JAVA_HOME environment variable.
3. Install Apache Tomcat 7 to provide the web server support.